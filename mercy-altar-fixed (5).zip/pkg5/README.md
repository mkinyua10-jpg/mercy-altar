# Mercy's Daily Altar — Installation Guide

## OPTION 1: GitHub Pages (Recommended — Full PWA)

### Step 1: Create a GitHub account
- Go to https://github.com
- Sign up for a free account (use any email)

### Step 2: Create a new repository
- Click the green "New" button on your GitHub dashboard
- Repository name: `mercy-altar` (exactly like this, lowercase)
- Make sure "Public" is selected
- Click "Create repository"

### Step 3: Upload your files
- On the repository page, click "uploading an existing file"
- Drag ALL FOUR files from this ZIP into the upload area:
  - index.html
  - manifest.json
  - sw.js
  - icon-192.png
  - icon-512.png
- Scroll down and click "Commit changes"

### Step 4: Enable GitHub Pages
- Click "Settings" (top menu of your repository)
- Scroll down to "Pages" in the left sidebar
- Under "Branch", select "main" and click Save
- Wait 2–3 minutes

### Step 5: Your app URL
Your app will be live at:
https://YOUR-GITHUB-USERNAME.github.io/mercy-altar/

### Step 6: Install on Android
- Open Chrome on your Android phone
- Go to your URL above
- Tap the 3-dot menu (⋮) → "Add to Home Screen" or "Install app"
- Tap "Install"
- Find it on your home screen — opens full screen like a real app ✦

---

## OPTION 2: Direct APK (No internet hosting needed)

Because building an APK requires Android SDK tools that aren't
available in this environment, use the FREE online tool PWABuilder:

### Step 1: Host on GitHub Pages first (Option 1 above)

### Step 2: Go to PWABuilder
- On your phone or computer, go to: https://www.pwabuilder.com
- Enter your GitHub Pages URL
- Click "Start"

### Step 3: Download APK
- Click "Android" on the results page
- Click "Download Package"
- You'll get an APK file

### Step 4: Install the APK on your Android
- Transfer the APK to your phone (WhatsApp to yourself, or email)
- On your phone: Settings → Security → enable "Install unknown apps"
- Open the APK file → Install
- Your app appears on your home screen

---

## Your app works OFFLINE
Once installed, Mercy's Daily Altar works without internet.
Farm notes save to your device automatically.
Declarations, check-ins and assignments are always available.

---

*Built with love. Proverbs 31:25 — She is clothed with strength and dignity.*
